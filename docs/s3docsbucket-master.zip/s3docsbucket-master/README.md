# s3docsbucket

Repo to generate home page for [QTMCoP's Docs](https://docs.qtmcop.tmr.qld.gov.au)

This is one of many repositories owned and organised by Transport and Main Roads.

## Repo Rules

The only rule is clean code - consistent with formatting standards by [Prettier](https://github.com/prettier/prettier) - best practice would be to enable prettier with whatever editor you use.
