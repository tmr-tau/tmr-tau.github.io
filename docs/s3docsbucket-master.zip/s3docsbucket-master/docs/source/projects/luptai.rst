Land-use Urban Planning and Transport Accessibility Indicator (LUPTAI) model.
=============================================================================

Follow this link for LUPTAI's docs [https://docs.qtmcop.tmr.qld.gov.au/luptai/index.html]
