Git / GitLab info
=================

.. include:: git/git_overview.rst
.. include:: git/git_installation.rst
.. include:: git/git_2fa.rst
.. include:: git/git_pycharm.rst